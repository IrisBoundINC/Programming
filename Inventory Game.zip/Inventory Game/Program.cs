﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Ethan Rangel

//(Note: Some of the pieces of code used for my midterm I learned via received help with via a friend of mine who specializes in progamming using Visual Studio)
//Once you win or lose, you can reset the game and make different choices by hitting 'Enter'







namespace AdventureGamePrototype
{
    class Program
    {
        static void Main(string[] args)
        {
            gameTitle();
            first();

        }
        public static void gameTitle()
        {
            Console.WriteLine("This is the game title!");
            Console.WriteLine("(This is a prototype, so everything is entirely placeholder texts, options, and outcomes.)");
            Console.WriteLine("(NOTE: Outcomes may be randomized or might not make sense! )");
            Console.WriteLine(". . .");
            Console.WriteLine(". . .");
            Console.WriteLine(". . .");
            Console.WriteLine("(Press 'Enter' to start!)");
            Console.ReadLine();
            Console.Clear();
            first();

        }

        //Code below I was able to do on my own

        public static void first()
        {
            string choice;
            Console.WriteLine("PLACEHOLDER TEXT");
            Console.WriteLine("PLACEHOLDER TEXT");
            Console.WriteLine("PLACEHOLDER TEXT");
            Console.WriteLine("...");
            Console.WriteLine("...");
            Console.WriteLine("...");
            Console.WriteLine("PLACEHOLDER TEXT");
            Console.WriteLine("PLACEHOLDER TEXT ?");
            Console.WriteLine("Option 1");
            Console.WriteLine("Option 2");
            Console.WriteLine("Option 3");
            Console.Write("Choice: ");
            choice = Console.ReadLine().ToLower();
            Console.Clear();

            switch (choice)
            {
                case "1":
                case "Option 1":
                case "Option Selected":
                    {

                        Console.WriteLine("PLACEHOLDER TEXT");
                        Console.WriteLine("PLACEHOLDER TEXT");
                        Console.WriteLine("PLACEHOLDER TEXT");
                        Console.WriteLine("PLACEHOLDER TEXT");
                        Console.WriteLine("PLACEHOLDER TEXT");
                        Console.ReadLine();
                        gameOver();
                        break;
                    }
                case "2":
                case "Option ":
                    {
                        Console.WriteLine("PLACEHOLDER TEXT");
                        Console.WriteLine("PLACEHOLDER TEXT");
                        Console.WriteLine("PLACEHOLDER TEXT");
                        Console.WriteLine("PLACEHOLDER TEXT");
                        Console.ReadLine();
                        second();
                        break;
                    }
                case "3":
                case "Option 3":
                case "With what she can find, she can create a shelter":
                    {
                        Console.WriteLine("PLACEHOLDER TEXT");
                        Console.WriteLine("PLACEHOLDER TEXT");
                        Console.WriteLine("PLACEHOLDER TEXT");
                        Console.ReadLine();
                        second();
                        break;
                    }
                default:
                    {

                        Console.WriteLine("Command is invalid...");
                        Console.WriteLine("Press 'Enter' to restart.");
                        Console.ReadLine();
                        first();
                        break;
                    }
            }
        }

        //Code below I received help from my friend

        public static void second()
        {
            Random rnd = new Random();
            string[] secondOptions = { "PLACEHOLDER PATH 1",
            "PLACEHOLDER PATH 2 w/ ?",
            "PLACEHOLDER PATH 3 w/ ?"};
            int randomNumber = rnd.Next(0, 3);
            string secText = secondOptions[randomNumber];

            string secChoice;

            Console.WriteLine(secText);
            Console.WriteLine("Yes or No?");
            Console.Write("Choice: ");
            secChoice = Console.ReadLine().ToLower();

            //I did this part on my own though. I'm more familiar with if-then-else scripts

            if (secChoice == "yes" || secChoice == "y")
            {
                Console.WriteLine("PLACEHOLDER TEXT");
                Console.ReadLine();
                Console.Clear();
                third();

            }
            else if (secChoice == "no" || secChoice == "n")
            {
                Console.WriteLine("Uh oh!!!");
                Console.WriteLine("PLACEHOLDER TEXT!");
                Console.WriteLine("PLACEHOLDER DECISION!!!");
                Console.ReadLine();
                gameOver();

            }
            else
            {
                Console.WriteLine("You must reply Yes or no.");
                Console.WriteLine("Press 'Enter' to continue.");
                Console.ReadLine();
                second();
            }

        }

        //Code below I received help from my friend, but I did most of it on my own

        public static void third()

        {
            int Decision;
            Console.WriteLine("PLACEHOLDER PATH 4");
            Console.WriteLine("PLACEHOLDER PATH 5 w/ ?");
            Console.WriteLine("PLACEHOLDER DECISION (type 1 or 2)");
            Console.Write("Decision: ");
            int.TryParse(Console.ReadLine(), out Decision);
            int loop = 0;
            bool dead = false;
            while (Decision != 1 && dead == false)
            {
                if (loop <= 0)
                {
                    Console.WriteLine("PLACEHOLDER TEXT");
                    Console.WriteLine("PLACEHOLDER DECISION (type 1 or 2)");
                    Console.Write("Decision: ");
                    int.TryParse(Console.ReadLine(), out Decision);
                    loop++;
                }
                else if (loop >= 1)
                {
                    Console.WriteLine("PLACEHOLDER OUTCOME");
                    Console.WriteLine("PLACEHOLDER DECISION (type 1 or 2) ");
                    Console.Write("Decision: ");
                    int.TryParse(Console.ReadLine(), out Decision);
                    dead = true;
                }

            }
            if (dead == true)
            {
                Console.WriteLine("PLACEHOLDER OUTCOME");
                Console.WriteLine("PLACEHOLDER TEXT");
                Console.ReadLine();
                gameOver();
            }
            else

            {
                Console.WriteLine("PLACEHOLDER OUTCOME");
                Console.WriteLine("PLACEHOLDER TEXT");
                Console.ReadLine();
                youWin();
            }
        }

        //Code below I was able to do on my own

        public static void gameOver()
        {
            Console.Clear();
            Console.WriteLine("PLACEHOLDER TEXT");
            Console.WriteLine("PLACEHOLDER TEXT");
            Console.WriteLine("PLACEHOLDER TEXT");
            Console.WriteLine("PLACEHOLDER TEXT");
            Console.WriteLine("GAME OVER..?");
            Console.WriteLine(". . .");
            Console.WriteLine("(Press 'Enter' to reset!)");
            Console.ReadLine();
            Console.Clear();
            gameTitle();
        }

        public static void youWin()
        {
            Console.Clear();
            Console.WriteLine("PLACEHOLDER TEXT!!!.");
            Console.WriteLine("PLACEHOLDER TEXT");
            Console.WriteLine("PLACEHOLDER TEXT!");
            Console.WriteLine("THE END!");
            Console.WriteLine(". . .");
            Console.WriteLine("(Press 'Enter' to reset!)");
            Console.ReadLine();
            Console.Clear();
            gameTitle();
        }


    }
}