﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//Ethan Rangel

//(Note: Some of the pieces of code used for my midterm I learned via received help with via a friend of mine who specializes in progamming using Visual Studio)
//Once you win or lose, you can reset the game and make different choices by hitting 'Enter'







namespace StromsQuest
{
    class Program
    {
        static void Main(string[] args)
        {
            gameTitle();
            first();

        }
        public static void gameTitle()
        {
            Console.WriteLine("This is Strom's Quest!!!.");
            Console.WriteLine("(NOTE: Outcomes may be randomized or might not make sense!)");
            Console.WriteLine(". . .");
            Console.WriteLine(". . .");
            Console.WriteLine(". . .");
            Console.WriteLine("(Press 'Enter' to commence forth!)");
            Console.ReadLine();
            Console.Clear();
            first();

        }

        //Code below I was able to do on my own

        public static void first()
        {
            string choice;
            Console.WriteLine("Strom seemed to have been minding her own business in her home world.");
            Console.WriteLine("One day however, she accidentally discovers that she can teleport herself into different dimensions by using a strange hand formation...");
            Console.WriteLine("She was thrown out into the giant web of all universes called the multiverse");
            Console.WriteLine("...");
            Console.WriteLine("...");
            Console.WriteLine("...");
            Console.WriteLine("Strom is now lost in the multiverse and is left stranded in a planet in Universe-48214-Y");
            Console.WriteLine("What can she do?");
            Console.WriteLine("1. Keep warping to different universes until she makes it home");
            Console.WriteLine("2. Seek intelligent life and make peace offerings");
            Console.WriteLine("3. With what she can find, she can create a shelter");
            Console.Write("Choice: ");
            choice = Console.ReadLine().ToLower();
            Console.Clear();

            switch (choice)
            {
                case "1":
                case "Keep warping to different universes until she makes it home":
                case "Keep":
                    {
                        Console.WriteLine("She warps herself into more and more universes");
                        Console.WriteLine("She warps and warps and warps, but to no avail.");
                        Console.WriteLine("It feels like forever since she last left the universe she first landed on.");
                        Console.WriteLine("Eventually... Without her realization, tears began to form across the multiverse!");
                        Console.WriteLine("It was damaging the multiverse from the inside, splitting everything apart.");
                        Console.WriteLine("Unfortunately, everything somehow ceases to exist.");
                        Console.ReadLine();
                        gameOver();
                        break;
                    }
                case "2":
                case "Seek intelligent life and make peace offerings":
                    {
                        Console.WriteLine("She searches for intelligent life in the planet");
                        Console.WriteLine("She finds human-like creatures and they seem to understand her language, sheer luck!");
                        Console.WriteLine("She makes peace offerings to them and eventually they accept her into their society and seek out a way to help her back home!");
                        Console.WriteLine("Unfortunately, they inform her that she will need to find her own source of food, as the food they eat isn't enough for Strom");
                        Console.ReadLine();
                        second();
                        break;
                    }
                case "3":
                case "Create":
                case "With what she can find, she can create a shelter":
                    {
                        Console.WriteLine("She finds what seems to be grey wood.");
                        Console.WriteLine("She finds enough to create a small triangular home with a layer of leaves to protect it from rain.");
                        Console.WriteLine("Strom is safe and sound... for now... as night approaches..!"); ;
                        Console.ReadLine();
                        second();
                        break;
                    }
                default:
                    {

                        Console.WriteLine("Command is invalid...");
                        Console.WriteLine("Press 'Enter' to restart.");
                        Console.ReadLine();
                        first();
                        break;
                    }
            }
        }

        //Code below I received help from my friend

        public static void second()
        {
            Random rnd = new Random();
            string[] secondOptions = { "A ferocious thunderstorm approaches, and Strom's shelter seems like it would be no match! Will she find more material in the forest?",
            "Strom has no food source at all! Will she search for food?",
            "Strom hears strange noises from afar. Will she approach the sounds?"};
            int randomNumber = rnd.Next(0, 3);
            string secText = secondOptions[randomNumber];

            string secChoice;

            Console.WriteLine(secText);
            Console.WriteLine("Yes or No?");
            Console.Write("Choice: ");
            secChoice = Console.ReadLine().ToLower();

            //I did this part on my own though. I'm more familiar with if-then-else scripts

            if (secChoice == "yes" || secChoice == "y")
            {
                Console.WriteLine("Strom feels as if something or someone is stalking her, but decides to ignore the feeling and continue.");
                Console.ReadLine();
                Console.Clear();
                third();

            }
            else if (secChoice == "no" || secChoice == "n")
            {
                Console.WriteLine("Uh oh!!!");
                Console.WriteLine("Strom mysteriously passes out!!!");
                Console.WriteLine("She is not waking up!!!");
                Console.ReadLine();
                gameOver();

            }
            else
            {
                Console.WriteLine("You must reply Yes or no.");
                Console.WriteLine("Press 'Enter' to continue.");
                Console.ReadLine();
                second();
            }

        }

        //Code below I received help from my friend, but I did most of it on my own

        public static void third()

        {
            int Decision;
            Console.WriteLine("An eerie noise can be heard from the depths of a nearby forrest!");
            Console.WriteLine("Strom's curiousity gets to the best of her and checks it out, only to find a shadowy figure! It comes at her! What will she do?");
            Console.WriteLine("Will she fight or flee? Type 1 or 2.");
            Console.Write("Decision: ");
            int.TryParse(Console.ReadLine(), out Decision);
            int loop = 0;
            bool dead = false;
            while (Decision != 1 && dead == false)
            {
                if (loop <= 0)
                {
                    Console.WriteLine("It casts strange spells at her.");
                    Console.WriteLine("The spell manages to hone onto her and hit her, causing her to feel dizzy, will she still fight or flee?");
                    Console.Write("Decision: ");
                    int.TryParse(Console.ReadLine(), out Decision);
                    loop++;
                }
                else if (loop >= 1)
                {
                    Console.WriteLine("The shadowy figure finally reaches her and tries to wrap around her.");
                    Console.WriteLine("Fear and adrenaline surge within the depths of her physique and spirit. Fight or Flee? (1 or 2?) ");
                    Console.Write("Decision: ");
                    int.TryParse(Console.ReadLine(), out Decision);
                    dead = true;
                }
                
            }
            if (dead == true)
            {
                Console.WriteLine("The shadowy figure envelopes around Strom!");
                Console.WriteLine("She is blinded by its darkness and slowly begins to fall asleep forever.");
                Console.ReadLine();
                gameOver();
            }
            else

            {
                Console.WriteLine("She dodges the shadowy figure's charge and manages to bring the light from the sky down towards it and it fades away!");
                Console.WriteLine("In its place, is a portal that leads her back home! Sheer luck!!!");
                Console.ReadLine();
                youWin();
            }
        }

        //Code below I was able to do on my own

        public static void gameOver()
        {
            Console.Clear();
            Console.WriteLine("Strom is now in deep trouble...");
            Console.WriteLine("All hope is lost...");
            Console.WriteLine("The Multiverse is gone...");
            Console.WriteLine("Another takes its place...");
            Console.WriteLine("GAME OVER..?");
            Console.WriteLine(". . .");
            Console.WriteLine("(Press 'Enter' to reset!)");
            Console.ReadLine();
            Console.Clear();
            gameTitle();
        }

        public static void youWin()
        {
            Console.Clear();
            Console.WriteLine("Strom makes it back to her home universe!!!.");
            Console.WriteLine("The Legends Class team has found her asleep nearby.");
            Console.WriteLine("She is reunited with all her friends and her father!");
            Console.WriteLine("THE END!");
            Console.WriteLine(". . .");
            Console.WriteLine("(Press 'Enter' to reset!)");
            Console.ReadLine();
            Console.Clear();
            gameTitle();
        }


    }
}